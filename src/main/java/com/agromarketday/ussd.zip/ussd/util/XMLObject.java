package com.agromarketday.ussd.util;

/**
 * all JAVA object representations of XML will implement this interface
 *
 * @author smallGod
 */
public interface XMLObject {
    public XMLObject getXMLObject();
}