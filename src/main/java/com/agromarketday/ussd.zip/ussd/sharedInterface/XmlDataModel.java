package com.agromarketday.ussd.sharedInterface;

/**
 * all JAVA object representations of XML will implement this interface
 *
 * @author smallGod
 */
public interface XmlDataModel {
    public XmlDataModel getXMLObject();    
}