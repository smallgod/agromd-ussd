package com.agromarketday.ussd.sharedInterface;

/**
 *
 * @author smallgod
 */
public interface MenuItem {

    public int getId();

    public String getName();

}
